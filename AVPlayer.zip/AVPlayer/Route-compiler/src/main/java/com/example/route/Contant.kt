package com.example.route

const val PACKAGE_PATH = "com.example.route"
const val ROOT_ROUTE_PATH = "com.example.route.Root"