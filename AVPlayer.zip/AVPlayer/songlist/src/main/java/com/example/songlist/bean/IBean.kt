package com.example.songlist.bean

interface IBean