package com.example.conmon

const val ACCOUNT = "account"
const val PASSWORD = "password"