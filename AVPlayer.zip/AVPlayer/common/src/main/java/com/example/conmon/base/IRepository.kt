package com.example.conmon.base

interface IRepository{
    val lifeCycleProvide:AndroidLifeCycleProvide
}